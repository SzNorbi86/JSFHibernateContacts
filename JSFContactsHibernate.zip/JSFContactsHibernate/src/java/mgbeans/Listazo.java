/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mgbeans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.hibernate.Query;
import org.hibernate.Session;
import pojos.Contact;
import pojos.Phone;

/**
 *
 * @author norbertszilagyi
 */
@ManagedBean
@SessionScoped
public class Listazo {

    private List<Contact> kontaktok;
    private List<Phone> telSzamok;
    private Contact kivalasztottKontakt;
    private String kereses;
    private Phone kivalasztottPhone;

    private Map<Integer, Contact> kontaktMap;
    private Map<Integer, Phone> phoneMap;

    public Listazo() {
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        kontaktok = session.createQuery("FROM Contact").list();
        session.close();

        kontaktMap = new HashMap<>();
        for (Contact c : kontaktok) {
            kontaktMap.put(c.getId(), c);
        }

        keress();

    }

    public void keress() {
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        Query q;
        q = session.createQuery("FROM Contact WHERE name LIKE :xxx");
        q.setString("xxx", kereses + "%");
        kontaktok = q.list();
        session.close();
        kivalasztottKontakt = null;
        kivalasztottPhone=null;

    }

    public void szamListaz(Contact kontakt) {
        kivalasztottKontakt = kontakt;
        telSzamok = new ArrayList<>(kivalasztottKontakt.getPhones());

    }

    public String ujKontakt() {
        kivalasztottKontakt = new Contact();
        kivalasztottPhone= new Phone();

        return "ujkontakt";
    }

    public String megsem() {
        kivalasztottKontakt = null;
        return "index";
    }

    public String contactModosit(Contact kontakt) {
        kivalasztottKontakt = kontakt;
        return "kontaktmodosit";

    }

    public String contactMentes() {
        boolean uj = kivalasztottKontakt.getId() == null;

        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        if (uj) {
            session.save(kivalasztottKontakt);

        } else {
            session.update(kivalasztottKontakt);

        }
        session.getTransaction().commit();
        session.close();
        keress();
        return "index";
    }
  
    public String szamMentes() {
        boolean uj = kivalasztottPhone.getId() == null;
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.saveOrUpdate(kivalasztottPhone);
        session.getTransaction().commit();
        session.close();
        if (uj) {
            telSzamok.add(kivalasztottPhone);
            kivalasztottKontakt.getPhones().add(kivalasztottPhone);
        }

        return "index";
    }

    public String editNumber(Phone phone) {
        kivalasztottPhone = phone;
        return "szammodosit";
    }

    public List<Contact> getKontaktok() {
        return kontaktok;
    }

    public void setKontaktok(List<Contact> kontaktok) {
        this.kontaktok = kontaktok;
    }

    public List<Phone> getTelSzamok() {
        return telSzamok;
    }

    public void setTelSzamok(List<Phone> telSzamok) {
        this.telSzamok = telSzamok;
    }

    public Contact getKivalasztottKontakt() {
        return kivalasztottKontakt;
    }

    public void setKivalasztottKontakt(Contact kivalasztottKontakt) {
        this.kivalasztottKontakt = kivalasztottKontakt;
    }

    public Map<Integer, Contact> getKontaktMap() {
        return kontaktMap;
    }

    public void setKontaktMap(Map<Integer, Contact> kontaktMap) {
        this.kontaktMap = kontaktMap;
    }

    public String getKereses() {
        return kereses;
    }

    public void setKereses(String kereses) {
        this.kereses = kereses;
    }

    public Phone getKivalasztottPhone() {
        return kivalasztottPhone;
    }

    public void setKivalasztottPhone(Phone kivalasztottPhone) {
        this.kivalasztottPhone = kivalasztottPhone;
    }

    public Map<Integer, Phone> getPhoneMap() {
        return phoneMap;
    }

    public void setPhoneMap(Map<Integer, Phone> phoneMap) {
        this.phoneMap = phoneMap;
    }

}
